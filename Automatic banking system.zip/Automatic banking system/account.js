function showCreateAccount() {
    document.getElementById('account-content').innerHTML = `
        <h3>Create Account</h3>
        <form>
            <input type="text" placeholder="Full Name" required>
            <input type="email" placeholder="Email" required>
            <input type="password" placeholder="Password" required>
            <button type="submit">Create Account</button>
        </form>
    `;
}

function showViewAccounts() {
    document.getElementById('account-content').innerHTML = `
        <h3>View Accounts</h3>
        <p>List of accounts will be displayed here.</p>
    `;
}

function showEditAccount() {
    document.getElementById('account-content').innerHTML = `
        <h3>Edit Account</h3>
        <form>
            <input type="text" placeholder="Account ID" required>
            <input type="text" placeholder="Full Name" required>
            <input type="email" placeholder="Email" required>
            <button type="submit">Edit Account</button>
        </form>
    `;
}

function showDeleteAccount() {
    document.getElementById('account-content').innerHTML = `
        <h3>Delete Account</h3>
        <form>
            <input type="text" placeholder="Account ID" required>
            <button type="submit">Delete Account</button>
        </form>
    `;
}
