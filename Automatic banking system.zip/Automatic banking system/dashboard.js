// Show/Hide Sections
function hideAllSections() {
    const sections = document.getElementsByClassName('content-section');
    for (let section of sections) {
        section.classList.add('hidden');
    }
}

function showAccountManagement() {
    hideAllSections();
    document.getElementById('account-management').classList.remove('hidden');
}

function showLoanServices() {
    hideAllSections();
    document.getElementById('loan-services').classList.remove('hidden');
}

function showTransactionServices() {
    hideAllSections();
    document.getElementById('transaction-services').classList.remove('hidden');
}

function showPersonalFinance() {
    hideAllSections();
    document.getElementById('personal-finance').classList.remove('hidden');
}

function showProfileManagement() {
    hideAllSections();
    document.getElementById('profile-management').classList.remove('hidden');
}

function showCustomerSupport() {
    hideAllSections();
    document.getElementById('customer-support').classList.remove('hidden');
}

function showNetBanking() {
    hideAllSections();
    document.getElementById('net-banking').classList.remove('hidden');
}

function showAccountBalance() {
    document.getElementById('netbanking-content').innerHTML = "<h3>Account Balance</h3><p>Your current balance is $5,000.</p>";
}

function showBillPayment() {
    document.getElementById('netbanking-content').innerHTML = `
        <h3>Pay Bills</h3>
        <form id="bill-payment-form">
            <label>Bill Amount: </label><input type="number" id="bill-amount" required>
            <button type="submit">Pay Now</button>
        </form>
    `;
    document.getElementById('bill-payment-form').onsubmit = function(event) {
        event.preventDefault();
        alert("Bill paid successfully.");
        document.getElementById('netbanking-content').innerHTML = '';
    };
}

function showManageBeneficiaries() {
    document.getElementById('netbanking-content').innerHTML = `
        <h3>Manage Beneficiaries</h3>
        <p>Add, edit, or remove beneficiaries here.</p>
        <form id="beneficiary-form">
            <label>Beneficiary Name: </label><input type="text" required>
            <button type="submit">Add Beneficiary</button>
        </form>
    `;
    document.getElementById('beneficiary-form').onsubmit = function(event) {
        event.preventDefault();
        alert("Beneficiary added successfully.");
        document.getElementById('netbanking-content').innerHTML = '';
    };
}

function showRecentTransactions() {
    document.getElementById('netbanking-content').innerHTML = `
        <h3>Recent Transactions</h3>
        <ul>
            <li>Transaction 1: -$100</li>
            <li>Transaction 2: +$500</li>
            <li>Transaction 3: -$50</li>
            <li>Transaction 4: +$200</li>
        </ul>
    `;
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = 'login.html';
    }
}
