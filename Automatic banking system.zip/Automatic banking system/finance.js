function showDeposit() {
    document.getElementById('transaction-content').innerHTML = `
        <h3>Deposit</h3>
        <form>
            <input type="number" placeholder="Amount" required>
            <input type="text" placeholder="Account ID" required>
            <button type="submit">Deposit</button>
        </form>
    `;
}

function showWithdraw() {
    document.getElementById('transaction-content').innerHTML = `
        <h3>Withdraw</h3>
        <form>
            <input type="number" placeholder="Amount" required>
            <input type="text" placeholder="Account ID" required>
            <button type="submit">Withdraw</button>
        </form>
    `;
}

function showTransfer() {
    document.getElementById('transaction-content').innerHTML = `
        <h3>Transfer</h3>
        <form>
            <input type="text" placeholder="From Account ID" required>
            <input type="text" placeholder="To Account ID" required>
            <input type="number" placeholder="Amount" required>
            <button type="submit">Transfer</button>
        </form>
    `;
}

function showTransactionHistory() {
    document.getElementById('transaction-content').innerHTML = `
        <h3>Transaction History</h3>
        <p>List of transactions will be displayed here.</p>
    `;
}
