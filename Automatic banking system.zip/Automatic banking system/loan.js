function showApplyLoan() {
    const content = `
        <h3>Apply for Loan</h3>
        <form>
            <input type="text" placeholder="Loan Type" required>
            <input type="number" placeholder="Amount" required>
            <input type="number" placeholder="Term (Years)" required>
            <button type="submit" class="btn">Apply</button>
        </form>
    `;
    document.getElementById('loan-content').innerHTML = content;
}

function showViewLoans() {
    const content = `
        <h3>View Loans</h3>
        <p>No loans available</p>
    `;
    document.getElementById('loan-content').innerHTML = content;
}

function showRepayLoan() {
    const content = `
        <h3>Repay Loan</h3>
        <form>
            <input type="text" placeholder="Loan ID" required>
            <input type="number" placeholder="Amount" required>
            <button type="submit" class="btn">Repay</button>
        </form>
    `;
    document.getElementById('loan-content').innerHTML = content;
}
