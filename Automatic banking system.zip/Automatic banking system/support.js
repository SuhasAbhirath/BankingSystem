document.getElementById('support-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Support request submitted successfully!');
});
